library form_group_comp;

import 'package:angular/angular.dart' show Component;

@Component(
  selector: 'x-form-group',
  template: '<content></content>',
  cssUrl: 'packages/pritunl/components/form_group/form_group.css'
)
class FormGroupComp {
}
