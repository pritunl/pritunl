def setup_poolers():
    from pritunl import poolers
