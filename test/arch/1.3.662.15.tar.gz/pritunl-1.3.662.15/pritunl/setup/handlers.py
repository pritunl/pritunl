from pritunl.constants import *
from pritunl.exceptions import *
from pritunl.helpers import *

def setup_handlers():
    from pritunl import handlers
